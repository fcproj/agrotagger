#! /bin/bash
./taggerDir.sh ../work/splitted ../work/output nutchOutput rdfnt 2>&1 > /dev/null &


