#! /bin/bash
./crawler_exec.sh 5 ../work/output ../work/urls/ 2>&1 > /dev/null &


